package edu.buffalo.cse.cse486586.simpledynamo;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.util.Formatter;
import java.util.HashMap;

public class OperationUtil {


    public static HashMap<String, String> readAllFromFile(Context context) {
        StringBuffer dataTotal = new StringBuffer();
        String data = null;

        HashMap<String,String> tempMap=new HashMap<String, String>();
        try {
            //Reading Value from File :
            //https://stackoverflow.com/questions/9095610/android-fileinputstream-read-txt-file-to-string
            File dirFiles = context.getFilesDir();
            for (String fileName : dirFiles.list()) {
                FileInputStream contentFile = context.openFileInput(fileName);

                StringBuffer fileContent = new StringBuffer("");
                byte[] buffer = new byte[1024];

                int ne;
                while ((ne = contentFile.read(buffer)) != -1) {
                    fileContent.append(new String(buffer, 0, ne));
                }
                data = fileContent.toString();
                tempMap.put(fileName,data);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("All Query Data" + dataTotal);
        return tempMap;
    }

    public static synchronized  void deleteOne(String fileName,Context context) {
        System.out.println("Deleting Single file:"+fileName);
        context.deleteFile(fileName);
    }
    public static synchronized void deleteAll(Context context)
    {


        File dirFiles = context.getFilesDir();
        for (String fileName : dirFiles.list()) {
            context.deleteFile(fileName);

    }
    }
    public static String readFromFile(String key,Context context) {
        String fileName = key;
        String data = null;

        try {
            //Reading Value from File :
            //https://stackoverflow.com/questions/9095610/android-fileinputstream-read-txt-file-to-string
            FileInputStream contentFile = context.openFileInput(fileName);

            StringBuffer fileContent = new StringBuffer("");
            byte[] buffer = new byte[1024];

            int ne;
            while ((ne = contentFile.read(buffer)) != -1) {
                fileContent.append(new String(buffer, 0, ne));
            }
            data = fileContent.toString();


        } catch (Exception e) {

        }
        return data;
    }

    public static String readAllFromFileString(Context context) {
        StringBuffer dataTotal = new StringBuffer();
        String data = null;

        try {
            //Reading Value from File :
            //https://stackoverflow.com/questions/9095610/android-fileinputstream-read-txt-file-to-string
            File dirFiles = context.getFilesDir();
            for (String fileName : dirFiles.list()) {
                FileInputStream contentFile = context.openFileInput(fileName);

                StringBuffer fileContent = new StringBuffer("");
                byte[] buffer = new byte[1024];

                int ne;
                while ((ne = contentFile.read(buffer)) != -1) {
                    fileContent.append(new String(buffer, 0, ne));
                }
                data = fileContent.toString();
                dataTotal.append(fileName).append(";").append(data).append(":");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("All Query Data" + dataTotal);
        return dataTotal.toString();
    }



}
