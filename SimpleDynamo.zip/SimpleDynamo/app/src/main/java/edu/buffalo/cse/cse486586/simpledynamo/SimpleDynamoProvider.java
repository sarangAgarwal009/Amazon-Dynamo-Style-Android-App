package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import android.annotation.SuppressLint;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDynamoProvider extends ContentProvider {

    public String myPort;
    public String myExtPort;
    public ArrayList<String> portList;
    public LinkedList<String> portListt = new LinkedList<String>();
    public HashMap<String, String> preferenceList = new HashMap<String, String>();

    public ArrayList<String> hashTable = new ArrayList<String>();
    public String pred[]=new String[2];
    public String succ[]=new String[2];
    private String myHash;
    private AtomicBoolean isDataGlobal = new AtomicBoolean(false);
    private AtomicBoolean isDataSingle = new AtomicBoolean(false);
    private AtomicBoolean isGlobalWrite = new AtomicBoolean(false);

    public boolean isNew = true;
    private long startTime;


    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {


        if (selection.equals("@")) {
            OperationUtil.deleteAll(getContext());
            return 1;
        }
        if (selection.equals("*")) {

            OperationUtil.deleteAll(getContext());
            new ClientDeletion().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, "1", "*");
            return 1;
        } else {
            if (String.valueOf(Integer.parseInt(myPort) * 2).equals(masterNode(genHash(selection)))) {
                OperationUtil.deleteOne(selection, getContext());
            } else {
                new ClientDeletion().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, masterNode(genHash(selection)), selection);
            }

        }


        return 0;
    }

    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {

        ArrayList<Boolean> trueList = new ArrayList<Boolean>();
        trueList.add(0, false);
        String key = values.getAsString("key");
        String value = values.getAsString("value");

        String responsibleNode = String.valueOf(Integer.parseInt(masterNode(genHash(key))) / 2);
        if (myPort.equals(responsibleNode)) {

            insertAtMe(key, value);  //insert locally
            insertAtSuc(key, value, trueList); //insert globally

            while (!trueList.get(0)) {

            }
            trueList.set(0, false);
        } else {

            sendMessage(responsibleNode, key + ":" + value + ":", "InsertOther", new HashMap<String, String>(), new ArrayList<Boolean>());
        }
        return null;
    }

    private void insertAtSuc(String key, String value, ArrayList<Boolean> trueList) {
        //Send message to my successors to insert a value..

        sendMessage(myPort, key + ":" + value + ":", "InsertRep", new HashMap<String, String>(), trueList);
    }


    public void insertAtMe(String key, String value) {

        Context ctx = getContext();
        FileOutputStream outputStream;
        try {
            synchronized (this) {
                outputStream = ctx.openFileOutput(key, Context.MODE_PRIVATE);
                outputStream.write(value.getBytes());
                outputStream.close();
            }
        } catch (Exception e) {
            Log.v("insert", "error in writing to file");
        }
    }

    public void sendMessage(String port, String msg, String command, HashMap<String, String> map, ArrayList<Boolean> trueList) {
        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, port, msg, command, map, trueList);
    }


    @Override
    public boolean onCreate() {
         startTime = System.currentTimeMillis() / (long) 1000;
        // isNew=true;
        TelephonyManager tel = (TelephonyManager) this.getContext().getSystemService(Context.TELEPHONY_SERVICE);
        myPort = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        myExtPort=String.valueOf((Integer.parseInt(myPort)*2));

        //have to multiply by 2 everywhere for actual port
        //  myPort = String.valueOf((Integer.parseInt(portStr) * 2));

        initializeConnections();

        try {

            ServerSocket serverSocket = new ServerSocket(10000);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);

            new ClientAwake().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,serverSocket);

        } catch (IOException e) {
            Log.info(e.getMessage());
        }
        isNew = false;
        return false;
    }

    public void sendFirstMessage() {

    }

    private void initializeConnections() {
        //portList=new ArrayList<String>();
        portListt.add(0, "11124");
        portListt.add(1, "11112");
        portListt.add(2, "11108");
        portListt.add(3, "11116");
        portListt.add(4, "11120");

        preferenceList.put("11124", "11124:11112:11108");
        preferenceList.put("11112", "11112:11108:11116");
        preferenceList.put("11108", "11108:11116:11120");
        preferenceList.put("11120", "11120:11124:11112");
        preferenceList.put("11116", "11116:11120:11124");
        if (myPort.equals("5554")) {
            succ[0] = "11116";
            succ[1]="11120";
            pred[0] = "11112";
            pred[1] = "11124";
        } else if (myPort.equals("5556")) {
            succ[0] = "11108";
            succ[1]="11116";
            pred[0] = "11124";
            pred[1] = "11120";
        } else if (myPort.equals("5558")) {
            succ[0] = "11120";
            succ[1]="11124";
            pred[0] = "11108";
            pred[1]="11112";
        } else if (myPort.equals("5560")) {
            succ[0] = "11124";
            succ[1]="11112";
            pred[0] = "11116";
            pred[1]="11108";
        } else {
            succ[0] = "11112";
            succ[1]="11108";
            pred[0] ="11120";
            pred[1] ="11116";
        }

        hashTable.add(0, genHash("5562"));
        hashTable.add(1, genHash("5556"));
        hashTable.add(2, genHash("5554"));
        hashTable.add(3, genHash("5558"));
        hashTable.add(4, genHash("5560"));
    }

    public  String readAllFromFileHash(Context context,String port) {
        //This function should take port number as 1111 and for each filename,if it belongs to the
        //respective key, only then it should add.
        StringBuffer dataTotal = new StringBuffer();
        String data = null;

        try {
            //Reading Value from File :
            //https://stackoverflow.com/questions/9095610/android-fileinputstream-read-txt-file-to-string
            File dirFiles = context.getFilesDir();
            for (String fileName : dirFiles.list()) {
                if(!masterNode(genHash(fileName)).equals(port))
                {
                    continue;
                }
                FileInputStream contentFile = context.openFileInput(fileName);

                StringBuffer fileContent = new StringBuffer("");
                byte[] buffer = new byte[1024];

                int ne;
                while ((ne = contentFile.read(buffer)) != -1) {
                    fileContent.append(new String(buffer, 0, ne));
                }
                data = fileContent.toString();
                dataTotal.append(fileName).append(";").append(data).append(":");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return dataTotal.toString();
    }



    public String masterNode(String dataHash) {

        for (int i = 4; i > 0; i--) {
            if (dataHash.compareTo(hashTable.get(4)) > 0 || dataHash.compareTo(hashTable.get(0)) < 0) {
                return portListt.get(0);
            }
            if (dataHash.compareTo(hashTable.get(i)) < 0 && dataHash.compareTo(hashTable.get(i - 1)) > 0) {
                return portListt.get(i);
            }

        }
        return null;
    }


    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        // TODO Auto-generated method stub


        HashMap<String, String> resultMap = new HashMap<String, String>();
        ArrayList<Boolean> trueList = new ArrayList<Boolean>();
        trueList.add(0, false);
        trueList.add(1, false);

        MatrixCursor mCursor = new MatrixCursor(new String[]{"key", "value"});
        if (selection.equals("*")) {
            //Multicast Message and get the result
            sendMessage("1", selection, "QueryAll", resultMap, trueList);

            while (!trueList.get(0)) {

            }
            trueList.set(0, false);
            resultMap.putAll(OperationUtil.readAllFromFile(getContext()));
            for (String key : resultMap.keySet()) {
                String valuee = resultMap.get(key);
                mCursor.addRow(new String[]{key, valuee});

            }

        } else if (selection.equals("@")) {
            resultMap.putAll(OperationUtil.readAllFromFile(getContext()));
            for (String key : resultMap.keySet()) {
                String valuee = resultMap.get(key);
                mCursor.addRow(new String[]{key, valuee});
            }



        } else if (String.valueOf(Integer.parseInt(myPort) * 2).equals(masterNode(genHash(selection)))) {
            //Code to fetch the data
            String value = OperationUtil.readFromFile(selection, getContext());
            mCursor.addRow(new String[]{selection, value});

        } else {
            //ReDirect to Node that has the data
            //keep holding the data for query
            sendMessage(masterNode(genHash(selection)), selection, "QuerySingle", resultMap, trueList);

            while (!trueList.get(1)) {

//                issue is other process making this flag treu
            }
            trueList.set(1, false);
            isDataSingle.set(false);
            //  String value = totalRecord.toString();
            mCursor.addRow(new String[]{selection, resultMap.get(selection)});
        }
        mCursor.setNotificationUri(getContext().getContentResolver(), uri);
        return mCursor;

    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {


        return 0;
    }

    private static String genHash(String input) {

        try {
            MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
            byte[] sha1Hash = sha1.digest(input.getBytes());
            Formatter formatter = new Formatter();
            for (byte b : sha1Hash) {
                formatter.format("%02x", b);
            }
            return formatter.toString();
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return null;
    }

    private class ClientTask extends AsyncTask<Object, Void, Void> {
        @Override
        protected Void doInBackground(Object... msgs) {
            String command = (String) msgs[2];
            String msg = (String) msgs[1];   //key:value:
            String headNode = (String) msgs[0];  //55 wala port
            String portToConnect = String.valueOf((Integer.parseInt(headNode) * 2));
            HashMap<String, String> resultMap = (HashMap<String, String>) msgs[3];
            ArrayList<Boolean> trueList = (ArrayList<Boolean>) msgs[4];
            if (command.equals("InsertRep")) {
                insertSuccData(msg, portToConnect, command);
                trueList.set(0, true);
                return null;
            }
            if (command.equals("InsertOther")) {
                insertSuccData(msg, portToConnect, command);
                // trueList.set(0,true);
            }
            if (command.equals("QueryAll")) {
                resultMap.putAll(readAllDataAll());
                trueList.set(0, true);
            }
            if (command.equals("QuerySingle")) {
                //this is the case when querying for a single key
                String resultt = readSingleDataClient(headNode, msg, command);
                resultMap.put(msg, resultt);
                trueList.set(1, true);

            }

            return null;
        }

        private String readSingleDataClient(String headNode, String msg, String command) {

            //This is the case when i am querying single key
            Socket socket = null;
            String msgServer = null;

            try {

                socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(headNode));  //head node is the main node being queried
                //  socket.setSoTimeout(1200);
                socket.setTcpNoDelay(true);
                PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
                printWriter.println(msg + ";" + command); //msg is Key to be searched
                InputStreamReader isr = new InputStreamReader(socket.getInputStream());
                BufferedReader inputBuffer = new BufferedReader(isr);
                msgServer = inputBuffer.readLine();

                if(null==msgServer)throw new Exception();
                return msgServer;


            } catch (Exception e) {
                e.printStackTrace();
                String succHeadNode = (preferenceList.get(headNode).split(":"))[1];
                msgServer = readSingleDataClient(succHeadNode, msg, command);
            }
            return msgServer;
        }

        private HashMap<String, String> readAllDataAll() {
            HashMap<String, String> tempMap = new HashMap<String, String>();
            Socket socket[] = new Socket[5];
            for (int i = 0; i < 5; i++) {
                try {
                    if (portListt.get(i).equals(String.valueOf((Integer.parseInt(myPort) * 2))))
                        continue;
                    socket[i] = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(portListt.get(i)));
                    // socket[i].setSoTimeout(1200);
                    socket[i].setTcpNoDelay(true);
                    PrintWriter printWriter = new PrintWriter(socket[i].getOutputStream(), true);
                    printWriter.println("QueryAll;"); //msg is Key to be searched
                    InputStreamReader isr = new InputStreamReader(socket[i].getInputStream());
                    BufferedReader inputBuffer = new BufferedReader(isr);
                    String msgServer = inputBuffer.readLine();

                    putDataToMap(msgServer, tempMap);
                    inputBuffer.close();
                    socket[i].close();


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
//                isDataGlobal.set(true);
            return tempMap;
        }

        public void putDataToMap(String msgServer, HashMap<String, String> tempMap) {

            //: se record separate honge, ; se key and value
            String[] rows = msgServer.toString().split(":");
            //HashMap<String, String> tempMap = new HashMap<String, String>();
            for (String vals : rows) {
                if (!(vals == null)) {
                    String key = (vals.split(";"))[0];
                    String valuee = (vals.split(";"))[1];
                    tempMap.put(key, valuee);
                }
            }


        }

        private void insertSuccData(String msg, String portToConnect, String command) {

            String portToSend[] = (preferenceList.get(portToConnect)).split(":");
            Socket socket = null;
            for (int i = 0; i < 3; i++) {
                try {
                    if (command.equals("InsertRep") && i == 0)
                        continue; // In case of replication from own node
                    if (portToSend[i].equals(String.valueOf((Integer.valueOf(myPort)) * 2))) {
                        insertAtMe((msg.split(":"))[0], (msg.split(":"))[1]);
                        continue;
                    }

                    socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(portToSend[i]));
                    //  socket.setSoTimeout(1200);
                    socket.setTcpNoDelay(true);
                    PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
                    printWriter.println((msg + command));    //key:value:command
                    InputStreamReader isr = new InputStreamReader(socket.getInputStream());
                    BufferedReader inputBuffer = new BufferedReader(isr);
                    String msgServer = inputBuffer.readLine();
                    inputBuffer.close();
                    socket.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
//            isGlobalWrite.set(true);
        }
    }


    //Server Task starts here


    public class ServerTask extends AsyncTask<ServerSocket, String, Void> {
        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];
            long polltime = System.currentTimeMillis() / (long) 1000;
            try {
                while (true) {
                    Socket socket = serverSocket.accept();
                    //   socket.setSoTimeout(1200);
                    socket.setTcpNoDelay(true);
                    String messageClient;

                    PrintWriter pos = new PrintWriter(socket.getOutputStream(), true);
                    InputStreamReader inputRead = new InputStreamReader(socket.getInputStream());
                    BufferedReader bufferRead = new BufferedReader(inputRead);

                    //FIRST MSG ARRIVED FROM CLIENT
                    messageClient = bufferRead.readLine();
                    if(messageClient.contains("MissingOwn"))
                    {
                        //return keys which belong to personsd
                        if(((long)System.currentTimeMillis() / (long) 1000-polltime)>6){
                            String clientArray[] = messageClient.split(":");

                            String portBeloning=clientArray[1]; //port here is 1111
                            String temp=   readAllFromFileHash(getContext(),portBeloning);
                            pos.println(temp); }
                        else {
                            pos.println("B");
                        }

                    }
                    else if(messageClient.contains("MissingPred")){
                        if(((long)System.currentTimeMillis() / (long) 1000-polltime)>6) {
                            //Return self keys only
                            String clientArray[] = messageClient.split(":");
                            String portBeloning = clientArray[1]; //port here is 1111
                            String temp = readAllFromFileHash(getContext(), portBeloning);
                            pos.println(temp);
                        }
                        else {
                            pos.println("B");
                        }

                    }
                    else  if (messageClient.contains("Insert")) {
                        String clientArray[] = messageClient.split(":");
                        String key = clientArray[0];
                        String value = clientArray[1];
                        insertAtMe(key, value);
                        pos.println("Hello");
                    } else if (messageClient.contains("QueryAll")) {
                        String reply = OperationUtil.readAllFromFileString(getContext());
                        pos.println(reply);
                    } else if (messageClient.contains("QuerySingle")) {
                        String replyy = OperationUtil.readFromFile((messageClient.split(";"))[0], getContext());
                        pos.println(replyy);
                    } else if (messageClient.contains("DeleteAll")) {


                        OperationUtil.deleteAll(getContext());
                        pos.println("OK");

                    } else if (messageClient.contains("Delete")) {

                        String key = (messageClient.split(";"))[0];
                        OperationUtil.deleteOne(key, getContext());
                        pos.println("OK");
                    }


                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }


    }


    private class ClientDeletion extends AsyncTask<Object, Void, Void> {
        //0 pe port to connect 1 pe message content
        @Override

        protected Void doInBackground(Object... msgs) {
            String msg = (String) msgs[1];
            String portSucc = (String) msgs[0];
            String nextSucc = "";
            Socket socket[] = new Socket[5];
            if (msg.contains("*")) {
                //Delete All
                deleteAllClient();
                return null;
            } else {
                //Delete specific data
                deleteSuccData(msg, portSucc, "DeleteOne");
            }
            return null;


        }
    }

    private void deleteAllClient() {
        Socket socket[] = new Socket[5];
        for (int i = 0; i < 5; i++) {
            try {
                if (portListt.get(i).equals(String.valueOf((Integer.parseInt(myPort) * 2))))
                    continue;
                socket[i] = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(portListt.get(i)));
                //  socket[i].setSoTimeout(1200);
                socket[i].setTcpNoDelay(true);
                PrintWriter printWriter = new PrintWriter(socket[i].getOutputStream(), true);
                printWriter.println("DeleteAll;"); //msg is Key to be searched
                InputStreamReader isr = new InputStreamReader(socket[i].getInputStream());
                BufferedReader inputBuffer = new BufferedReader(isr);
                String msgServer = inputBuffer.readLine();
                inputBuffer.close();
                socket[i].close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }


    }


    private void deleteSuccData(String msg, String portToConnect, String command) {

        String portToSend[] = (preferenceList.get(portToConnect)).split(":");
        Socket socket = null;
        for (int i = 0; i < 3; i++) {
            try {
                // In case of replication from own node
                if (portToSend[i].equals(String.valueOf((Integer.parseInt(myPort)) * 2))) {
                    OperationUtil.deleteOne(msg, getContext());
                    continue;

                }
                socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(portToSend[i]));
                //   socket.setSoTimeout(1200);
                socket.setTcpNoDelay(true);
                PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
                printWriter.println((msg + ";" + command));    //key:DeleteOne
                InputStreamReader isr = new InputStreamReader(socket.getInputStream());
                BufferedReader inputBuffer = new BufferedReader(isr);
                String msgServer = inputBuffer.readLine();
                inputBuffer.close();
                socket.close();
            } catch (Exception e) {
                e.printStackTrace();

            }
        }

    }


    private class ClientAwake extends AsyncTask<Object, Void, Void> {
        //0 pe port to connect 1 pe message content
        @Override

        protected Void doInBackground(Object... msgs) {
            //Have to send it to 2 Successors and 2 Predecessors
            for (int i = 0; i < 2; i++) {
                Socket socket[]=new Socket[2];
                try {
                    // In case of replication from own node

                    socket[i] = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(succ[i]));
                    //    socket[i].setSoTimeout(1200);
                    socket[i].setTcpNoDelay(true);
                    PrintWriter printWriter = new PrintWriter(socket[i].getOutputStream(), true);
                    printWriter.println(("MissingOwn" + ":" + myExtPort));    //key:DeleteOne
                    InputStreamReader isr = new InputStreamReader(socket[i].getInputStream());
                    BufferedReader inputBuffer = new BufferedReader(isr);
                    String msgServer = inputBuffer.readLine();
                    if(null!=msgServer&&!"".equals(msgServer.trim())&&!"B".equals(msgServer)){
                        HashMap<String,String> tempMap=new HashMap<String,String>();
                        putDataToMap(msgServer,tempMap);
                        for(String key:tempMap.keySet())
                        {
                            insertAtMe1(key,tempMap.get(key));
                        }}
                    inputBuffer.close();
                    socket[i].close();
                } catch (Exception e) {
                    e.printStackTrace();

                }
            }

            for (int i = 0; i < 2; i++) {
                Socket socket[]=new Socket[2];
                try {
                    // In case of replication from own node

                    socket[i] = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(pred[i]));
                    //     socket[i].setSoTimeout(1200);
                    socket[i].setTcpNoDelay(true);
                    PrintWriter printWriter = new PrintWriter(socket[i].getOutputStream(), true);
                    printWriter.println(("MissingPred" + ":" + pred[i]));    //key:DeleteOne
                    InputStreamReader isr = new InputStreamReader(socket[i].getInputStream());
                    BufferedReader inputBuffer = new BufferedReader(isr);
                    String msgServer = inputBuffer.readLine();
                    if(null!=msgServer&&!"".equals(msgServer.trim())&&!"B".equals(msgServer)) {
                        HashMap<String, String> tempMap = new HashMap<String, String>();
                        putDataToMap(msgServer, tempMap);
                        for (String key : tempMap.keySet()) {
                            insertAtMe1(key, tempMap.get(key));
                        }
                    }
                    inputBuffer.close();
                    socket[i].close();
                } catch (Exception e) {
                    e.printStackTrace();

                }
            }
            return null;
        }
        public void insertAtMe1(String key, String value) {

            Context ctx = getContext();
            FileOutputStream outputStream;
            try {

                outputStream = ctx.openFileOutput(key, Context.MODE_PRIVATE);
                outputStream.write(value.getBytes());
                outputStream.close();

            } catch (Exception e) {
                Log.v("insert", "error in writing to file");
            }
        }

        public void putDataToMap(String msgServer, HashMap<String, String> tempMap) {

            //: se record separate honge, ; se key and value
            String[] rows = msgServer.toString().split(":");
            //HashMap<String, String> tempMap = new HashMap<String, String>();
            for (String vals : rows) {
                if (!(vals == null)) {
                    String key = (vals.split(";"))[0];
                    String valuee = (vals.split(";"))[1];
                    tempMap.put(key, valuee);
                }
            }
        }
    }
}
